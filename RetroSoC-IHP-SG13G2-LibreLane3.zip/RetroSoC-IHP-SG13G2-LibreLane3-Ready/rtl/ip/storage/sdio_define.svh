// Copyright (c) 2026 Yuchi Miao <miaoyuchi@ict.ac.cn>
// retroSoC is licensed under Mulan PSL v2.
// You can use this software according to the terms and conditions of the Mulan PSL v2.
// You may obtain a copy of Mulan PSL v2 at:
//             http://license.coscl.org.cn/MulanPSL2
// THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
// EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
// MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
// See the Mulan PSL v2 for more details.

`ifndef RETROSOC_SDIO_DEFINE_SVH
`define RETROSOC_SDIO_DEFINE_SVH

// verilog_format: off -- preserve the reviewed APB ABI column alignment
`define APB4_SDIO__IP_ID             12'h000
`define APB4_SDIO__IP_VERSION        12'h004
`define APB4_SDIO__CAPABILITY        12'h008
`define APB4_SDIO__HOST_CTRL         12'h00C
`define APB4_SDIO__CLOCK_CTRL        12'h010
`define APB4_SDIO__CLOCK_ACTUAL      12'h014
`define APB4_SDIO__BUS_CTRL          12'h018
`define APB4_SDIO__TIMEOUT_CMD       12'h01C
`define APB4_SDIO__TIMEOUT_DATA      12'h020
`define APB4_SDIO__TIMEOUT_BUSY      12'h024
`define APB4_SDIO__STATUS            12'h028
`define APB4_SDIO__PRESENT           12'h02C

`define APB4_SDIO__CMD_ARG           12'h040
`define APB4_SDIO__CMD_CFG           12'h044
`define APB4_SDIO__CMD_START          12'h048
`define APB4_SDIO__CMD_STATUS         12'h04C
`define APB4_SDIO__RESP0              12'h050
`define APB4_SDIO__RESP1              12'h054
`define APB4_SDIO__RESP2              12'h058
`define APB4_SDIO__RESP3              12'h05C
`define APB4_SDIO__RESP4              12'h060

`define APB4_SDIO__BLOCK_SIZE         12'h080
`define APB4_SDIO__BLOCK_COUNT        12'h084
`define APB4_SDIO__DATA_CFG           12'h088
`define APB4_SDIO__DATA_START         12'h08C
`define APB4_SDIO__PIO_DATA           12'h090
`define APB4_SDIO__FIFO_STATUS        12'h094
`define APB4_SDIO__FIFO_WATERMARK     12'h098

`define APB4_SDIO__DESC_BASE          12'h0C0
`define APB4_SDIO__DESC_COUNT         12'h0C4
`define APB4_SDIO__DMA_CTRL           12'h0C8
`define APB4_SDIO__DMA_STATUS         12'h0CC
`define APB4_SDIO__CURRENT_DESC       12'h0D0
`define APB4_SDIO__BYTES_DONE         12'h0D4
`define APB4_SDIO__DMA_ERROR_ADDR     12'h0D8
`define APB4_SDIO__DMA_ERROR          12'h0DC

`define APB4_SDIO__IRQ_STATUS         12'h100
`define APB4_SDIO__IRQ_ENABLE         12'h104
`define APB4_SDIO__IRQ_TEST           12'h108
`define APB4_SDIO__ERROR_STATUS       12'h10C
`define APB4_SDIO__ERROR_ABORT         7
`define APB4_SDIO__LAST_CMD           12'h110
`define APB4_SDIO__CRC_ERROR_COUNT    12'h114
`define APB4_SDIO__TIMEOUT_COUNT      12'h118
`define APB4_SDIO__AXI_ERROR_COUNT    12'h11C
`define APB4_SDIO__STALL_COUNT        12'h120
`define APB4_SDIO__DEBUG              12'h124

`define APB4_SDIO__HOST_CTRL_ENABLE   0
`define APB4_SDIO__HOST_CTRL_ABORT    1
`define APB4_SDIO__HOST_CTRL_IRQ      2
`define APB4_SDIO__CLOCK_CTRL_ENABLE  0
`define APB4_SDIO__CLOCK_CTRL_HALF_PERIOD_LSB 8
`define APB4_SDIO__BUS_CTRL_WIDTH_LSB 0
`define APB4_SDIO__BUS_CTRL_WIDTH_1   0
`define APB4_SDIO__BUS_CTRL_WIDTH_4   1
`define APB4_SDIO__CMD_CFG_INDEX_LSB  0
`define APB4_SDIO__CMD_CFG_RESP_LSB   8
`define APB4_SDIO__CMD_CFG_CRC_CHECK  12
`define APB4_SDIO__CMD_CFG_INDEX_CHECK 13
`define APB4_SDIO__RESP_NONE           0
`define APB4_SDIO__RESP_R1             1
`define APB4_SDIO__RESP_R1B            2
`define APB4_SDIO__RESP_R2             3
`define APB4_SDIO__RESP_R3             4
`define APB4_SDIO__RESP_R4             5
`define APB4_SDIO__RESP_R5             6
`define APB4_SDIO__RESP_R6             7
`define APB4_SDIO__RESP_R7             8
`define APB4_SDIO__DATA_CFG_DIRECTION 0
`define APB4_SDIO__DATA_CFG_WIDTH_LSB 1
`define APB4_SDIO__DATA_CFG_DMA       4
`define APB4_SDIO__DATA_CFG_BLOCK     5
`define APB4_SDIO__DATA_CFG_FIXED     6
`define APB4_SDIO__DMA_CTRL_START     0
`define APB4_SDIO__DMA_CTRL_ABORT     1
`define APB4_SDIO__DESC_OWN            0
`define APB4_SDIO__DESC_CHAIN          1
`define APB4_SDIO__DESC_END            2
`define APB4_SDIO__DESC_IRQ            3
`define APB4_SDIO__DESC_DONE           16
`define APB4_SDIO__DESC_ERROR          17

`define APB4_SDIO__IRQ_CMD_DONE       0
`define APB4_SDIO__IRQ_DATA_DONE      1
`define APB4_SDIO__IRQ_DMA_DONE       2
`define APB4_SDIO__IRQ_CMD_ERROR      3
`define APB4_SDIO__IRQ_DATA_ERROR     4
`define APB4_SDIO__IRQ_DMA_ERROR      5
`define APB4_SDIO__IRQ_DAT1           6
`define APB4_SDIO__IRQ_ABORT          7

`define APB4_SDIO__CAP_SD_MEMORY_V2   0
`define APB4_SDIO__CAP_SDIO_V2        1
`define APB4_SDIO__CAP_BUS_1BIT       2
`define APB4_SDIO__CAP_BUS_4BIT       3
`define APB4_SDIO__CAP_SDR            4
`define APB4_SDIO__CAP_SG_DMA         5
`define APB4_SDIO__CAP_PIO            6
`define APB4_SDIO__CAP_CRC            7
`define APB4_SDIO__CAP_MAX_BURST_16   8
// verilog_format: on

`endif
