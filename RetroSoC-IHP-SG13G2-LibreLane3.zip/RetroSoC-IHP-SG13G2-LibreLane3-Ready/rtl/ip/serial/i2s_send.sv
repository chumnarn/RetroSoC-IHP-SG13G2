// Copyright (c) 2023-2026 Yuchi Miao <miaoyuchi@ict.ac.cn>
// retroSoC is licensed under Mulan PSL v2.
// You can use this software according to the terms and conditions of the Mulan PSL v2.
// You may obtain a copy of Mulan PSL v2 at:
//             http://license.coscl.org.cn/MulanPSL2
// THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
// EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
// MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
// See the Mulan PSL v2 for more details.

module i2s_send (
    input  logic        clk_i,
    input  logic        rst_n_i,
    input  logic        sclk_pos_i,
    input  logic        sclk_fall_i,
    input  logic        lrck_i,
    input  logic        bitmode_i,
    input  logic [23:0] data_i,
    output logic        dacdat_o,
    output logic        done_o
);

  logic s_lrck_dely_d, s_lrck_dely_q;
  logic s_lrck_trg;
  logic [4:0] s_bit_cnt_d, s_bit_cnt_q;
  logic [4:0] s_bit_num;
  logic [23:0] s_xfer_data_d, s_xfer_data_q;
  logic s_dacdat_d, s_dacdat_q;


  assign s_bit_num     = bitmode_i ? 5'd23 : 5'd15;
  assign s_lrck_trg    = lrck_i ^ s_lrck_dely_q;
  assign dacdat_o      = s_dacdat_q;
  assign done_o        = s_bit_cnt_q == s_bit_num;


  assign s_lrck_dely_d = lrck_i;
  dffer #(
      .DATA_WIDTH(1)
  ) u_lrck_dely_dffer (
      .clk_i  (clk_i),
      .rst_n_i(rst_n_i),
      .en_i   (sclk_pos_i),
      .dat_i  (s_lrck_dely_d),
      .dat_o  (s_lrck_dely_q)
  );


  always_comb begin
    s_bit_cnt_d = s_bit_cnt_q;
    if (s_lrck_trg) s_bit_cnt_d = '0;
    else begin
      if (s_bit_cnt_q < s_bit_num) begin
        s_bit_cnt_d = s_bit_cnt_q + 1'b1;
      end
    end
  end
  dffer #(
      .DATA_WIDTH(5)
  ) u_bit_cnt_dffer (
      .clk_i  (clk_i),
      .rst_n_i(rst_n_i),
      .en_i   (sclk_pos_i),
      .dat_i  (s_bit_cnt_d),
      .dat_o  (s_bit_cnt_q)
  );


  always_comb begin
    s_xfer_data_d = s_xfer_data_q;
    if (s_lrck_trg) begin
      s_xfer_data_d = data_i;
    end else if (s_bit_cnt_q < s_bit_num) begin
      if (bitmode_i) begin
        s_xfer_data_d = {s_xfer_data_q[22:0], 1'b0};
      end else begin
        s_xfer_data_d[23:16] = s_xfer_data_q[23:16];
        s_xfer_data_d[15:0]  = {s_xfer_data_q[14:0], 1'b0};
      end
    end
  end
  dffer #(
      .DATA_WIDTH(24)
  ) u_xfer_data_dffer (
      .clk_i  (clk_i),
      .rst_n_i(rst_n_i),
      .en_i   (sclk_pos_i),
      .dat_i  (s_xfer_data_d),
      .dat_o  (s_xfer_data_q)
  );


  always_comb begin
    s_dacdat_d = s_dacdat_q;
    if (s_bit_cnt_q <= s_bit_num) begin
      if (bitmode_i) s_dacdat_d = s_xfer_data_q[23];
      else s_dacdat_d = s_xfer_data_q[15];
    end
  end
  dffer #(
      .DATA_WIDTH(1)
  ) u_dacdat_dffer (
      .clk_i  (clk_i),
      .rst_n_i(rst_n_i),
      .en_i   (sclk_fall_i),
      .dat_i  (s_dacdat_d),
      .dat_o  (s_dacdat_q)
  );

endmodule
